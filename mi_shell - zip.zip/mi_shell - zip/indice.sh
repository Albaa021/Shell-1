#!/bin/bash

BLUE="\e[34m"
RESET="\e[0m"
ORANGE="\e[33m"

# Función para mostrar la fecha y la hora
diayhora() {
    echo "Introduce tu nombre: "
    read usuario
    fecha=$(date +%d-%m-%Y)
    hora=$(date +%H:%M)
    echo "Hola $usuario, hoy es $fecha a las $hora, y estás conectada al equipo 💥PAM💥."
}

# Función para mostrar un dibujo ASCII# Si el argumento coincide con una función, la ejecutamos directamente
dibujo() {
        ./dibujo.sh
}

# Función para instalar y ejecutar el minijuego
minigame() {
    echo "Instalando pacman4console..."
    sudo apt-get update && sudo apt-get install -y pacman4console
    pacman4console
}

case "$1" in
    "indice")
        echo -e "${ORANGE} Comandos disponibles: ${RESET}"
        echo -e "${BLUE} indice: ${RESET} Muestra esta página."
        echo -e "${BLUE} pacman: ${RESET} Jugar al pacman."
        echo -e "${BLUE} tetris: ${RESET} Jugar al tetris."
        echo -e "${BLUE} dibujo: ${RESET} Enseñar un dibujo."
        echo -e "${BLUE} exit: ${RESET} Salir de la shell."
        echo -e "${BLUE} diayhora: ${RESET} Enseñar el día y la hora."
        echo -e "${BLUE} Cualquier otro comando de Linux también es ejecutable. ${RESET}"
	;;
 	
	"exit")
            echo -e "${BLUE} Saliendo de la shell...${RESET}"
            kill -9 $$
            ;;

        "dibujo")
            dibujo
            ;;

        "minigame")
            minigame
            ;;

        "diayhora")
            diayhora
            ;;
        "pacman")
           pacman4console
           ;;

        "tetris")
            tint
            ;;

        *)
            # Si no es un comando personalizado, ejecutarlo como un comando del sistema
            eval "$input"
            ;;	
	esac

# Mostrar encabezado de índice
echo -e "${BLUE} Escriba 'indice' para ver la lista de comandos ${RESET}"

while true; do
    echo -ne "${ORANGE}mi_shell>${RESET} "
    read -r input
    comando=$(echo "$input" | awk '{print $1}')
    args=$(echo "$input" | cut -d' ' -f2-)

    case "$comando" in
        "indice")
            echo -e "${ORANGE} Comandos disponibles: ${RESET}"
            echo -e "${BLUE} indice: ${RESET} Muestra esta página."
            echo -e "${BLUE} pacman: ${RESET} Jugar al pacman."
            echo -e "${BLUE} tetris: ${RESET} Jugar al tetris."
            echo -e "${BLUE} dibujo: ${RESET} Enseñar un dibujo."
            echo -e "${BLUE} exit: ${RESET} Salir de la shell."
            echo -e "${BLUE} diayhora: ${RESET} Enseñar el día y la hora."
            echo -e "${BLUE} Cualquier otro comando de Linux también es ejecutable. ${RESET}"
            ;;
        
        "exit")
            echo -e "${BLUE} Saliendo de la shell...${RESET}"
            kill -9 $$
            ;;

        "dibujo")
            dibujo
            ;;

        "minigame")
            minigame
            ;;

        "diayhora")
            diayhora
            ;;
	"pacman")
	   pacman4console
	   ;; 

        "tetris")
            tint
            ;;

        *)
            # Si no es un comando personalizado, ejecutarlo como un comando del sistema
            eval "$input"
            ;;
    esac
done
