#!/bin/bash

# Definir la partitura con líneas y notas en diferentes posiciones
notas=(
    "🎵-------------"
    "---🎵----------"
    "------🎵-------"
    "---------🎵----"
    "------------🎵-"
)

# Número de iteraciones antes de detenerse
limite=30  
contador=0  

# Bucle para animar la partitura
while [ $contador -lt $limite ]; do
    clear
    echo "🎼===================="

    # Imprimir la partitura con las notas
    for i in {0..4}; do
        echo "${notas[i]}"
    done

    echo "🎼===================="

    # Mover las notas a la derecha
    for i in {0..4}; do
        # Si la nota está al final, vuelve al inicio
        if [[ ${notas[i]: -1} == "🎵" ]]; then
            notas[i]="🎵-------------"
        else
            notas[i]="-${notas[i]}"   # Agregar un '-' al inicio para mover la nota
            notas[i]=${notas[i]:0:15} # Limitar el tamaño para que no crezca demasiado
        fi
    done

    sleep 0.3
    ((contador++))  # Aumentar el contador
done
